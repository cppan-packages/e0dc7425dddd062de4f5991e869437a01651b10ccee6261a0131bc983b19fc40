#include <Sery/Buffer.hh>
#include <sstream>
#include <iomanip>
#include <string.h>
#include <cassert>

namespace Sery
{

Buffer::Buffer()
  : _buffer()
{
}

Buffer::Buffer(const char* buffer, std::size_t size)
  : _buffer(buffer, buffer + size)
{
}

Buffer::~Buffer()
{
}

void        Buffer::writeRaw(const char* buffer, std::size_t size)
{
  _buffer.insert(_buffer.end(), buffer, buffer + size);
}

void        Buffer::readRaw(char* buffer, std::size_t size)
{
  memcpy(buffer, _buffer.data(), size);
  _buffer.erase(_buffer.begin(), _buffer.begin() + size);
}

std::size_t Buffer::size() const
{
  return _buffer.size();
}

const char* Buffer::data() const
{
  return _buffer.data();
}

void        Buffer::clear()
{
  _buffer.clear();
}

void        Buffer::setContent(const char* buffer, std::size_t size)
{
  clear();
  _buffer.insert(_buffer.end(), buffer, buffer + size);
}

const std::string Buffer::debug(uint8 width) const
{
  assert(width > 0);
  const char        *data = _buffer.data();
  std::stringstream stream;

  stream << std::setfill('0') << std::hex;
  for (uint32 i = 0; i < _buffer.size(); ++i)
  {
    uint32  k = i + 1;
    if (k > 1 && i % width != 0)
      stream << ' ';
    uint8 c = data[i];
    stream << std::setw(2) << (unsigned int)c;
    if (k % width == 0 && k < _buffer.size())
      stream << '\n';
  }
  return stream.str();
}

} // namespace Sery
